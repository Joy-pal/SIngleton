/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstproject;

/**
 *
 * @author Joy
 */
public class FirstProject {

    private static Singleton s,s1;
    private static TextSingleton t,t1;

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
       
        s=Singleton.getSingleton();
        s1=Singleton.getSingleton();
        
        t=TextSingleton.getInstance();
        t1=TextSingleton.getInstance();
       
       if(s!=null){
           System.out.println(s.toString());
           System.out.println(s1.toString());
           
           
       } 
       
        else
            System.out.println("not instantiated");System.out.println(t.toString());
           System.out.println(t1.toString());
    }
    
}
